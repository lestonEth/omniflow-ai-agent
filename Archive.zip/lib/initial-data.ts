import type { Node } from "@xyflow/react"

// Create a starting flow with a webhook trigger connected to a text processor
export const initialNodes: Node[] = []

