import CustomEdge from "@/components/custome-edge/custom-edge"

export const edgeTypes = {
    default: CustomEdge,
}

