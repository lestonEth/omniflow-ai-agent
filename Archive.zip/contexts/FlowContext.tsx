"use client"

import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react'
import {
    Node, Edge, ReactFlowInstance, applyNodeChanges, applyEdgeChanges, addEdge

} from "@xyflow/react"

interface FlowContextType {
    nodes: Node[]
    edges: Edge[]
    reactFlowInstance: ReactFlowInstance | null
    selectedNode: Node | null
    setNodes: React.Dispatch<React.SetStateAction<Node[]>>
    setEdges: React.Dispatch<React.SetStateAction<Edge[]>>
    setReactFlowInstance: React.Dispatch<React.SetStateAction<ReactFlowInstance | null>>
    setSelectedNode: React.Dispatch<React.SetStateAction<Node | null>>
    onNodesChange: (changes: any) => void
    onEdgesChange: (changes: any) => void
    onConnect: (connection: any) => void
    updateNodeData: (nodeId: string, newData: Partial<any>) => void
}

const FlowContext = createContext<FlowContextType | undefined>(undefined)

export const FlowProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [nodes, setNodes] = useState<Node[]>([])
    const [edges, setEdges] = useState<Edge[]>([])
    const [reactFlowInstance, setReactFlowInstance] = useState<ReactFlowInstance | null>(null)
    const [selectedNode, setSelectedNode] = useState<Node | null>(null)

    const onNodesChange = (changes: any) => {
        setNodes((nds) => applyNodeChanges(changes, nds))
    }

    const onEdgesChange = (changes: any) => {
        setEdges((eds) => applyEdgeChanges(changes, eds))
    }

    const onConnect = (connection: any) => {
        setEdges((eds) => addEdge(connection, eds))
    }

    const updateNodeData = useCallback(
        (nodeId: string, newData: Partial<any>) => {
            setNodes((currentNodes) => {
                // First update the target node
                const updatedNodes = currentNodes.map((node) =>
                    node.id === nodeId ? { ...node, data: { ...node.data, ...newData } } : node,
                )

                // Find all edges where this node is the source
                const outgoingEdges = edges.filter((edge) => edge.source === nodeId)

                // For each outgoing edge, update the target node's input
                outgoingEdges.forEach((edge) => {
                    const targetNode = updatedNodes.find((node) => node.id === edge.target)
                    if (targetNode && edge.sourceHandle && edge.targetHandle) {
                        // Get the output data from the source node
                        const sourceNode = updatedNodes.find((node) => node.id === nodeId)
                        if (sourceNode && sourceNode.data.outputData && sourceNode.data.outputData[edge.sourceHandle]) {
                            // Find the input in the target node that corresponds to the target handle
                            const targetInputs = [...(targetNode.data.inputs || [])]
                            const inputIndex = targetInputs.findIndex((input) => input.key === edge.targetHandle)

                            if (inputIndex !== -1) {
                                // Update the input value
                                targetInputs[inputIndex] = {
                                    ...targetInputs[inputIndex],
                                    value: sourceNode.data.outputData[edge.sourceHandle],
                                }

                                // Update the target node
                                const targetNodeIndex = updatedNodes.findIndex((node) => node.id === edge.target)
                                if (targetNodeIndex !== -1) {
                                    updatedNodes[targetNodeIndex] = {
                                        ...updatedNodes[targetNodeIndex],
                                        data: {
                                            ...updatedNodes[targetNodeIndex].data,
                                            inputs: targetInputs,
                                        },
                                    }
                                }
                            }
                        }
                    }
                })

                return updatedNodes
            })
        },
        [edges, setNodes],
    )

    return (
        <FlowContext.Provider
            value={{
                nodes,
                edges,
                reactFlowInstance,
                selectedNode,
                setNodes,
                setEdges,
                setReactFlowInstance,
                setSelectedNode,
                onNodesChange,
                onEdgesChange,
                onConnect,
                updateNodeData,
            }}
        >
            {children}
        </FlowContext.Provider>
    )
}

export const useFlow = () => {
    const context = useContext(FlowContext)
    if (!context) {
        throw new Error('useFlow must be used within a FlowProvider')
    }
    return context
}